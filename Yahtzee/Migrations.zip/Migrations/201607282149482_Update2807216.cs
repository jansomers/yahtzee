namespace Yahtzee.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Update2807216 : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Games", "GameResultA_Id", "dbo.GameResults");
            DropForeignKey("dbo.Games", "GameResultB_Id", "dbo.GameResults");
            DropIndex("dbo.Games", new[] { "GameResultA_Id" });
            DropIndex("dbo.Games", new[] { "GameResultB_Id" });
            DropIndex("dbo.Games", new[] { "PlayerB_Id" });
            RenameColumn(table: "dbo.Games", name: "PlayerA_Id", newName: "PlayerAId");
            RenameColumn(table: "dbo.Games", name: "PlayerB_Id", newName: "PlayerBId");
            RenameIndex(table: "dbo.Games", name: "IX_PlayerA_Id", newName: "IX_PlayerAId");
            AddColumn("dbo.Games", "GameName", c => c.String(maxLength: 40));
            AlterColumn("dbo.Games", "PlayerBId", c => c.String(nullable: false, maxLength: 128));
            CreateIndex("dbo.Games", "PlayerBId");
            DropColumn("dbo.Games", "GameResultA_Id");
            DropColumn("dbo.Games", "GameResultB_Id");
            DropTable("dbo.GameResults");
        }
        
        public override void Down()
        {
            CreateTable(
                "dbo.GameResults",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                    })
                .PrimaryKey(t => t.Id);
            
            AddColumn("dbo.Games", "GameResultB_Id", c => c.Int());
            AddColumn("dbo.Games", "GameResultA_Id", c => c.Int());
            DropIndex("dbo.Games", new[] { "PlayerBId" });
            AlterColumn("dbo.Games", "PlayerBId", c => c.String(maxLength: 128));
            DropColumn("dbo.Games", "GameName");
            RenameIndex(table: "dbo.Games", name: "IX_PlayerAId", newName: "IX_PlayerA_Id");
            RenameColumn(table: "dbo.Games", name: "PlayerBId", newName: "PlayerB_Id");
            RenameColumn(table: "dbo.Games", name: "PlayerAId", newName: "PlayerA_Id");
            CreateIndex("dbo.Games", "PlayerB_Id");
            CreateIndex("dbo.Games", "GameResultB_Id");
            CreateIndex("dbo.Games", "GameResultA_Id");
            AddForeignKey("dbo.Games", "GameResultB_Id", "dbo.GameResults", "Id");
            AddForeignKey("dbo.Games", "GameResultA_Id", "dbo.GameResults", "Id");
        }
    }
}
