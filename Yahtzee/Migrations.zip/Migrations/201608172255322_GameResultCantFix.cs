namespace Yahtzee.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class GameResultCantFix : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.GameResults", "GameResultId", "dbo.Games");
            DropIndex("dbo.GameResults", new[] { "GameResultId" });
            AddColumn("dbo.GameResults", "Game_Id", c => c.Int());
            CreateIndex("dbo.GameResults", "Game_Id");
            AddForeignKey("dbo.GameResults", "Game_Id", "dbo.Games", "Id");
            DropColumn("dbo.Games", "GameResultAId");
            DropColumn("dbo.Games", "GameResultBId");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Games", "GameResultBId", c => c.Int(nullable: false));
            AddColumn("dbo.Games", "GameResultAId", c => c.Int(nullable: false));
            DropForeignKey("dbo.GameResults", "Game_Id", "dbo.Games");
            DropIndex("dbo.GameResults", new[] { "Game_Id" });
            DropColumn("dbo.GameResults", "Game_Id");
            CreateIndex("dbo.GameResults", "GameResultId");
            AddForeignKey("dbo.GameResults", "GameResultId", "dbo.Games", "Id");
        }
    }
}
