namespace Yahtzee.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class GameResultFix4 : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Games", "GameResultA_GameResultId", "dbo.GameResults");
            DropForeignKey("dbo.Games", "GameResultB_GameResultId", "dbo.GameResults");
            DropIndex("dbo.GameResults", new[] { "GameResultId" });
            DropPrimaryKey("dbo.GameResults");
            AlterColumn("dbo.GameResults", "GameResultId", c => c.Int(nullable: false, identity: true));
            AddPrimaryKey("dbo.GameResults", "GameResultId");
            CreateIndex("dbo.GameResults", "GameResultId");
            AddForeignKey("dbo.Games", "GameResultA_GameResultId", "dbo.GameResults", "GameResultId");
            AddForeignKey("dbo.Games", "GameResultB_GameResultId", "dbo.GameResults", "GameResultId");
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Games", "GameResultB_GameResultId", "dbo.GameResults");
            DropForeignKey("dbo.Games", "GameResultA_GameResultId", "dbo.GameResults");
            DropIndex("dbo.GameResults", new[] { "GameResultId" });
            DropPrimaryKey("dbo.GameResults");
            AlterColumn("dbo.GameResults", "GameResultId", c => c.Int(nullable: false));
            AddPrimaryKey("dbo.GameResults", "GameResultId");
            CreateIndex("dbo.GameResults", "GameResultId");
            AddForeignKey("dbo.Games", "GameResultB_GameResultId", "dbo.GameResults", "GameResultId");
            AddForeignKey("dbo.Games", "GameResultA_GameResultId", "dbo.GameResults", "GameResultId");
        }
    }
}
