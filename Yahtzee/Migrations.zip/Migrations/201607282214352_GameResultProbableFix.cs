namespace Yahtzee.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class GameResultProbableFix : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.GameResults",
                c => new
                    {
                        GameResultId = c.Int(nullable: false, identity: true),
                    })
                .PrimaryKey(t => t.GameResultId);
            
            AddColumn("dbo.Games", "GameResultA_GameResultId", c => c.Int());
            AddColumn("dbo.Games", "GameResultB_GameResultId", c => c.Int());
            CreateIndex("dbo.Games", "GameResultA_GameResultId");
            CreateIndex("dbo.Games", "GameResultB_GameResultId");
            AddForeignKey("dbo.Games", "GameResultA_GameResultId", "dbo.GameResults", "GameResultId");
            AddForeignKey("dbo.Games", "GameResultB_GameResultId", "dbo.GameResults", "GameResultId");
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Games", "GameResultB_GameResultId", "dbo.GameResults");
            DropForeignKey("dbo.Games", "GameResultA_GameResultId", "dbo.GameResults");
            DropIndex("dbo.Games", new[] { "GameResultB_GameResultId" });
            DropIndex("dbo.Games", new[] { "GameResultA_GameResultId" });
            DropColumn("dbo.Games", "GameResultB_GameResultId");
            DropColumn("dbo.Games", "GameResultA_GameResultId");
            DropTable("dbo.GameResults");
        }
    }
}
