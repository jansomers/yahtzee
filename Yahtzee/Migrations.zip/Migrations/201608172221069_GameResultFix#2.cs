namespace Yahtzee.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class GameResultFix2 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Games", "GameResultAId", c => c.Int(nullable: false));
            AddColumn("dbo.Games", "GameResultBId", c => c.Int(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Games", "GameResultBId");
            DropColumn("dbo.Games", "GameResultAId");
        }
    }
}
