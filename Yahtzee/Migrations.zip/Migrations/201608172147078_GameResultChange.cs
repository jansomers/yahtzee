namespace Yahtzee.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class GameResultChange : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.GameResults", "Ones", c => c.Int(nullable: false));
            AddColumn("dbo.GameResults", "Twos", c => c.Int(nullable: false));
            AddColumn("dbo.GameResults", "Threes", c => c.Int(nullable: false));
            AddColumn("dbo.GameResults", "Fours", c => c.Int(nullable: false));
            AddColumn("dbo.GameResults", "Fives", c => c.Int(nullable: false));
            AddColumn("dbo.GameResults", "Sixes", c => c.Int(nullable: false));
            AddColumn("dbo.GameResults", "Tok", c => c.Int(nullable: false));
            AddColumn("dbo.GameResults", "Fok", c => c.Int(nullable: false));
            AddColumn("dbo.GameResults", "Fh", c => c.Int(nullable: false));
            AddColumn("dbo.GameResults", "SmStr", c => c.Int(nullable: false));
            AddColumn("dbo.GameResults", "LaStr", c => c.Int(nullable: false));
            AddColumn("dbo.GameResults", "Yahtzee", c => c.Int(nullable: false));
            AddColumn("dbo.GameResults", "Chance", c => c.Int(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.GameResults", "Chance");
            DropColumn("dbo.GameResults", "Yahtzee");
            DropColumn("dbo.GameResults", "LaStr");
            DropColumn("dbo.GameResults", "SmStr");
            DropColumn("dbo.GameResults", "Fh");
            DropColumn("dbo.GameResults", "Fok");
            DropColumn("dbo.GameResults", "Tok");
            DropColumn("dbo.GameResults", "Sixes");
            DropColumn("dbo.GameResults", "Fives");
            DropColumn("dbo.GameResults", "Fours");
            DropColumn("dbo.GameResults", "Threes");
            DropColumn("dbo.GameResults", "Twos");
            DropColumn("dbo.GameResults", "Ones");
        }
    }
}
