namespace Yahtzee.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ScreenName : DbMigration
    {
        public override void Up()
        {
            DropIndex("dbo.Games", new[] { "PlayerB_Id" });
            AddColumn("dbo.AspNetUsers", "ScreenName", c => c.String());
            AlterColumn("dbo.Games", "PlayerB_Id", c => c.String(maxLength: 128));
            CreateIndex("dbo.Games", "PlayerB_Id");
            DropColumn("dbo.GameResults", "TotalOnes");
        }
        
        public override void Down()
        {
            AddColumn("dbo.GameResults", "TotalOnes", c => c.Int(nullable: false));
            DropIndex("dbo.Games", new[] { "PlayerB_Id" });
            AlterColumn("dbo.Games", "PlayerB_Id", c => c.String(nullable: false, maxLength: 128));
            DropColumn("dbo.AspNetUsers", "ScreenName");
            CreateIndex("dbo.Games", "PlayerB_Id");
        }
    }
}
