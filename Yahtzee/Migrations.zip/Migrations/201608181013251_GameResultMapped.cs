namespace Yahtzee.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class GameResultMapped : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.GameResults", "Game_Id", "dbo.Games");
            DropIndex("dbo.GameResults", new[] { "Game_Id" });
            RenameColumn(table: "dbo.GameResults", name: "Game_Id", newName: "GameId");
            RenameColumn(table: "dbo.Games", name: "GameResultA_GameResultId", newName: "GameResultAId");
            RenameColumn(table: "dbo.Games", name: "GameResultB_GameResultId", newName: "GameResultBId");
            RenameIndex(table: "dbo.Games", name: "IX_GameResultA_GameResultId", newName: "IX_GameResultAId");
            RenameIndex(table: "dbo.Games", name: "IX_GameResultB_GameResultId", newName: "IX_GameResultBId");
            AlterColumn("dbo.GameResults", "GameId", c => c.Int(nullable: false));
            AlterColumn("dbo.Games", "GameName", c => c.String(maxLength: 20));
            CreateIndex("dbo.GameResults", "GameId");
            AddForeignKey("dbo.GameResults", "GameId", "dbo.Games", "Id", cascadeDelete: true);
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.GameResults", "GameId", "dbo.Games");
            DropIndex("dbo.GameResults", new[] { "GameId" });
            AlterColumn("dbo.Games", "GameName", c => c.String(maxLength: 40));
            AlterColumn("dbo.GameResults", "GameId", c => c.Int());
            RenameIndex(table: "dbo.Games", name: "IX_GameResultBId", newName: "IX_GameResultB_GameResultId");
            RenameIndex(table: "dbo.Games", name: "IX_GameResultAId", newName: "IX_GameResultA_GameResultId");
            RenameColumn(table: "dbo.Games", name: "GameResultBId", newName: "GameResultB_GameResultId");
            RenameColumn(table: "dbo.Games", name: "GameResultAId", newName: "GameResultA_GameResultId");
            RenameColumn(table: "dbo.GameResults", name: "GameId", newName: "Game_Id");
            CreateIndex("dbo.GameResults", "Game_Id");
            AddForeignKey("dbo.GameResults", "Game_Id", "dbo.Games", "Id");
        }
    }
}
